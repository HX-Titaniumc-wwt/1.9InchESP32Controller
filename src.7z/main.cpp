#include <Arduino.h>
#include <TFT_eSPI.h>
#include <lvgl.h>
#include "ui.h"
#include "myfunc.h"
#include "Wire.h"
// #define CGRAM_OFFSET

int pwmfreq = 0;
String i2caddrmain;
bool scani2cmain = false;
TaskHandle_t taskscani2c;

static const uint16_t screenWidth = 320;
// static const uint16_t screenHeight = 210;
static const uint16_t screenHeight = 170;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[screenWidth * screenHeight / 10];

TFT_eSPI tft = TFT_eSPI(screenWidth, screenHeight); /* TFT instance */

/* Display flushing */
void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p)
{
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.pushColors((uint16_t *)&color_p->full, w * h, true);
    tft.endWrite();

    lv_disp_flush_ready(disp_drv);
}
uint8_t button_read()
{
    if (digitalRead(GPIO_NUM_34) == 0)
    {
        // Serial.write("UP");
        return 1;
    }
    else if (digitalRead(GPIO_NUM_32) == 0)
    {
        // Serial.write("LEFT");
        return 2;
    }
    else if (digitalRead(GPIO_NUM_35) == 0)
    {
        // Serial.write("ENTER");
        return 3;
    }
    else if (digitalRead(GPIO_NUM_39) == 0)
    {
        // Serial.write("RIGHT");
        return 4;
    }
    else if (digitalRead(GPIO_NUM_0) == 0)
    {
        // Serial.write("DOWN");
        return 5;
    }
    return 0;
}
void keyboard_read(lv_indev_drv_t *indev_drv, lv_indev_data_t *data)
{
    static uint32_t last_key = 0;
    uint32_t act_key = button_read();
    if (act_key != 0)
    {
        data->state = LV_INDEV_STATE_PR;
        switch (act_key)
        {
        case 1:
            act_key = LV_KEY_PREV;
            break;
        case 2:
            act_key = LV_KEY_LEFT;
            break;
        case 3:
            act_key = LV_KEY_ENTER;
            break;
        case 4:
            act_key = LV_KEY_RIGHT;
            break;
        case 5:
            act_key = LV_KEY_NEXT;
            break;
        default:
            break;
        }
        last_key = act_key;
    }
    else
    {
        data->state = LV_INDEV_STATE_REL;
    }
    data->key = last_key;
}

void ChangeGroupfunc_MainScreen(); // 创建主界面输入组文件
void RTOS_scani2c(void *scani2c);
void i2cScanmain();

void setup()
{
    // 设置IO状态
    pinMode(GPIO_NUM_34, INPUT); // 上
    pinMode(GPIO_NUM_32, INPUT); // 左
    pinMode(GPIO_NUM_35, INPUT); // 确认
    pinMode(GPIO_NUM_39, INPUT); // 右
    pinMode(GPIO_NUM_0, INPUT);  // 下
    pinMode(GPIO_NUM_15, OUTPUT);
    pinMode(GPIO_NUM_25, OUTPUT);
    pinMode(GPIO_NUM_26, OUTPUT);
    pinMode(GPIO_NUM_33, OUTPUT);

    Serial.begin(115200); /* prepare for possible serial debug */
    Wire.begin(21,22);
    // i2cScanmain();
    lv_init();

    tft.begin();        /* TFT init */
    tft.setRotation(1); /* Landscape orientation, flipped */
    lv_disp_draw_buf_init(&draw_buf, buf, NULL, screenWidth * screenHeight / 10);

    /*Initialize the display*/
    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    /*Change the following line to your display resolution*/
    disp_drv.hor_res = screenWidth;
    disp_drv.ver_res = screenHeight;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.draw_buf = &draw_buf;
    lv_disp_drv_register(&disp_drv);

    // /*Initialize the (dummy) input device driver*/
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_KEYPAD;
    indev_drv.read_cb = keyboard_read;
    indev_keypad = lv_indev_drv_register(&indev_drv);

    analogWrite(TFT_BL, 70);
    ui_init();
    ChangeGroupfunc_MainScreen();
}

void loop()
{
    lv_timer_handler(); /* let the GUI do its work */
    String a = lv_label_get_text(ui_StaticLabelI2CScreen);
    // Serial.println(a);
    if (a == "Scanning")
    {
        // Serial.println("进入");
        if (taskscani2c == NULL)
        {
            // Serial.println("NULL");
            scani2cmain = true;
            xTaskCreate(RTOS_scani2c, "RTOS_scani2c", 1024*2, NULL, 1, &taskscani2c);
        }
        else if (scani2cmain = false)
        {
            // Serial.println("进入false");
            vTaskDelete(taskscani2c);
        }
        else{
            // vTaskDelete(taskscani2c);
        }
    
    }
    
    delay(20);
}

void ChangeGroupfunc_MainScreen()
{
    // 创建主页面前组
    Group_MianScreenGroup = lv_group_create();
    lv_group_add_obj(Group_MianScreenGroup, ui_BtnIOControl);
    lv_group_add_obj(Group_MianScreenGroup, ui_BtnI2cScan);
    lv_group_add_obj(Group_MianScreenGroup, ui_BtnUartTest);
    lv_group_add_obj(Group_MianScreenGroup, ui_BtnSet);
    lv_indev_set_group(indev_keypad, Group_MianScreenGroup);
    // 创建IO控制组
    Group_IOScreenGroup = lv_group_create();
    lv_group_add_obj(Group_IOScreenGroup, ui_BtnIOScreenBack);
    lv_group_add_obj(Group_IOScreenGroup, ui_IO25SetBTN);
    lv_group_add_obj(Group_IOScreenGroup, ui_Dropdown2);
    lv_group_add_obj(Group_IOScreenGroup, ui_SwitchIO25ONOFF);

    lv_group_add_obj(Group_IOScreenGroup, ui_IO26SetBTN);
    lv_group_add_obj(Group_IOScreenGroup, ui_Dropdown1);
    lv_group_add_obj(Group_IOScreenGroup, ui_SwitchIO26ONOFF);

    lv_group_add_obj(Group_IOScreenGroup, ui_IO33SetBTN);
    lv_group_add_obj(Group_IOScreenGroup, ui_Dropdown3);
    lv_group_add_obj(Group_IOScreenGroup, ui_SwitchIO33ONOFF);

    // 创建PWM控制组
    Group_IOScreenPWMGroup = lv_group_create();
    lv_group_add_obj(Group_IOScreenPWMGroup, ui_SliderFreqChanged);
    lv_group_add_obj(Group_IOScreenPWMGroup, ui_SliderDutyChanged);
    lv_group_add_obj(Group_IOScreenPWMGroup, ui_Button2);

    // 创建I2c控制组
    Group_I2cScreenGroup = lv_group_create();
    lv_group_add_obj(Group_I2cScreenGroup, ui_BtnI2cBack);
    lv_group_add_obj(Group_I2cScreenGroup, ui_BtnI2cScanBtn);

    // 创建Uart控制组
    Group_UartScreenGroup = lv_group_create();
    lv_group_add_obj(Group_UartScreenGroup, ui_BtnUartBack1);

    // 创建Set控制组
    Group_SetScreenGroup = lv_group_create();
    lv_group_add_obj(Group_SetScreenGroup, ui_BtnSetBack);
    lv_group_add_obj(Group_SetScreenGroup, ui_Slider3);
}

void RTOS_scani2c(void *scani2c){
    byte error, address;
    int nDevices;
    Serial.println("Scanning...");
    nDevices = 0;
    for (address = 1; address < 127; address++)
    {
        // The i2c_scanner uses the return value of
        // the Write.endTransmisstion to see if
        // a device did acknowledge to the address.
        Wire.beginTransmission(address);
        error = Wire.endTransmission();
        if (error == 0)
        {
            Serial.print("I2C device found at address 0x");
            if (address < 16)
                Serial.print("0");
            Serial.print(address, HEX);
            char convertoff[10];
            sprintf(convertoff, "%x", (char)address);
            i2caddrmain += convertoff;
            i2caddrmain += ",";
            // Serial.println(convertoff);
            nDevices++;
        }
        else if (error == 4)
        {
            Serial.print("Unknow error at address 0x");
            if (address < 16)
                Serial.print("0");
            Serial.println(address, HEX);
        }
    }
    if (nDevices == 0)
        Serial.println("No I2C devices found\n");
    else
        Serial.println(i2caddrmain);
    
    // scani2cbool = false;
    scani2cmain = false;
    // xQueueSend()
    lv_label_set_text_fmt(ui_StaticLabelI2CScreen, "Result:\n0x:%s", i2caddrmain);
    vTaskDelete(NULL);
}


void i2cScanmain()
{
}